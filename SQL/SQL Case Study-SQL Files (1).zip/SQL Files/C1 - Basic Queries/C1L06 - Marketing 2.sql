-- Question 1
SELECT
  COUNT(*)
FROM
  dimStockItem
WHERE
  [Stock Item] LIKE '%mug%'
  OR [Stock Item] LIKE '%shirt%'
  
  -- Question 2
SELECT
  COUNT(*)
FROM
  dimStockItem
WHERE
  (
    [Stock Item] LIKE '%mug%'
    OR [Stock Item] LIKE '%shirt%'
  )
  AND Color = 'Black'

  -- Question 3
SELECT
  [WWI Stock Item ID],
  [Stock Item],
  [Unit Price]
FROM
  dimStockItem
WHERE
  (
    [Stock Item] LIKE '%mug%'
    OR [Stock Item] LIKE '%shirt%'
  )
  AND Color = 'Black'
ORDER BY
  [Unit Price],
  [WWI Stock Item ID]

  -- Question 4
SELECT
  [WWI Stock Item ID],
  [Stock Item],
  CAST(
    ([Recommended Retail Price] - [Unit Price]) / [Unit Price] AS decimal(10, 4)
  ) AS Markup
FROM
  dimStockItem
WHERE
  [WWI Stock Item ID] = 29