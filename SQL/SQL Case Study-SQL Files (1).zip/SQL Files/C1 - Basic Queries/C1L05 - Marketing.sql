-- Question 1
SELECT
  MIN([Unit Price])
FROM
  dimStockItem
WHERE
  [Stock Item] <> 'unknown'

  -- Question 2
SELECT
  [Stock Item]
FROM
  dimStockItem
WHERE
  [Unit Price] = 0.66

  -- Question 3
SELECT
  *
FROM
  dimStockItem
WHERE
  [Stock Item] <> 'unknown'
  AND [Stock Item] NOT LIKE '%box%'
  AND [Stock Item] NOT LIKE '%bag%'
  AND [Stock Item] NOT LIKE '%carton%'
ORDER BY
  [Unit Price]