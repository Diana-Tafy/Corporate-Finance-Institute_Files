-- Question 2
SELECT
  COUNT(*)
FROM
  dimStockItem

-- Question 3
SELECT
  COUNT(DISTINCT [Stock Item])
FROM
  dimStockItem
WHERE
  [Stock Item] <> 'unknown'