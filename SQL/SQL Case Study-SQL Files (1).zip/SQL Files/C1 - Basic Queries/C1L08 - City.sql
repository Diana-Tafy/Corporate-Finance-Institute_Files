-- Question 1
SELECT [Sales Territory], SUM([Latest Recorded Population]) AS Population
FROM dimCity
GROUP BY [Sales Territory]
ORDER BY Population DESC

-- Question 2
SELECT COUNT([City Key])
FROM dimCity
WHERE [Sales Territory] = 'Southeast'

-- Question 3
SELECT MAX([Latest Recorded Population])
FROM dimCity
WHERE [Sales Territory] = 'Southeast'

-- Question 4
SELECT SUM([Latest Recorded Population]) AS Population
FROM dimCity