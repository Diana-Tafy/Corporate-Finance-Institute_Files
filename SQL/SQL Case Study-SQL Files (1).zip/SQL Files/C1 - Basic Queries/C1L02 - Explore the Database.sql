-- Question 1
SELECT
  COUNT(*)
FROM
  factSale

-- Question 4
SELECT
  TOP 1000 *
FROM
  Staging_factSale