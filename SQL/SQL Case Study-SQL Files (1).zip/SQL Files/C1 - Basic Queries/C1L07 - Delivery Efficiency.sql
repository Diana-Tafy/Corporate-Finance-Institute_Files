-- Question 1
SELECT
  [Buying Group],
  COUNT([Customer Key]) AS CustomerCount
FROM
  dimCustomer
GROUP BY
  [Buying Group]
ORDER BY
  CustomerCount DESC

  -- Question 2
SELECT
  [Postal Code],
  COUNT([Customer Key]) AS CustomerCount
FROM
  dimCustomer
WHERE
  [Buying Group] = 'Wingtip Toys'
GROUP BY
  [Postal Code]
HAVING
  COUNT([Customer Key]) > 3
  
SELECT
  *
FROM
  dimCustomer
WHERE
  [Buying Group] = 'Wingtip Toys'
  AND [Postal Code] = '90683'