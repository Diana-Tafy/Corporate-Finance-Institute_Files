-- Question 2
SELECT
  COUNT(*)
FROM
  dimCustomer

-- Question 3
SELECT
  COUNT(*)
FROM
  dimCustomer
WHERE
  Customer = 'unknown'

-- Question 4
SELECT
  COUNT([Customer Key])
FROM
  dimCustomer
WHERE
  Customer <> 'unknown'