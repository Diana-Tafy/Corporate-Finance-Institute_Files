-- Question 1
SELECT
  p.[Stock Item] AS Product,
  SUM(s.Quantity) AS QuantitySold
FROM
  dimStockItem AS p
  LEFT JOIN factSale AS s ON p.[Stock Item Key] = s.[Stock Item Key]
WHERE p.[Is Chiller Stock] = 1
GROUP BY p.[Stock Item]
HAVING SUM(s.Quantity) IS NULL
ORDER BY QuantitySold DESC