-- Question 1
SELECT
  SUM([Total Excluding Tax]) AS TotalSales
FROM
  factSale AS s
  INNER JOIN dimDate AS d ON d.[Date] = s.[Invoice Date Key]
WHERE [Fiscal Year] = 2016

-- Question 2
SELECT TOP (5)
  p.[Stock Item] AS Product,
  SUM([Total Excluding Tax]) AS TotalSales
FROM
  factSale AS s
  INNER JOIN dimDate AS d ON d.[Date] = s.[Invoice Date Key]
  INNER JOIN dimStockItem AS p ON p.[Stock Item Key] = s.[Stock Item Key]
WHERE [Fiscal Year] = 2016
GROUP BY p.[Stock Item]
ORDER BY TotalSales DESC

-- Question 3
SELECT TOP (5)
  e.Employee AS SalesPerson,
  p.[Stock Item] AS Product,
  SUM([Total Excluding Tax]) AS TotalSales
FROM
  factSale AS s
  INNER JOIN dimDate AS d ON d.[Date] = s.[Invoice Date Key]
  INNER JOIN dimStockItem AS p ON p.[Stock Item Key] = s.[Stock Item Key]
  INNER JOIN dimEmployee AS e ON e.[Employee Key] = s.[Salesperson Key]
WHERE [Fiscal Year] = 2016
GROUP BY e.Employee, p.[Stock Item]
ORDER BY TotalSales DESC

-- Question 4
SELECT YEAR(GETDATE())