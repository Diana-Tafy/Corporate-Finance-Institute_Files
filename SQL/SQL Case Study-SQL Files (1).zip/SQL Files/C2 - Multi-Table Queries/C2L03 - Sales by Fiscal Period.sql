-- Question 1 & 2
SELECT
  d.[Fiscal Year],
  SUM([Total Excluding Tax]) AS TotalSales,
  SUM(Quantity) AS QuantitySold,
  SUM(Profit) AS Profit
FROM
  factSale AS s
  INNER JOIN dimDate AS d ON d.[Date] = s.[Invoice Date Key]
GROUP BY
  d.[Fiscal Year]
ORDER BY
  d.[Fiscal Year]

-- Question 3
SELECT
  d.[Fiscal Year],
  d.[Fiscal Month Number],
  d.[Fiscal Month Label],
  SUM([Total Excluding Tax]) AS TotalSales,
  SUM(Quantity) AS QuantitySold,
  SUM(Profit) AS Profit
FROM
  factSale AS s
  INNER JOIN dimDate AS d ON d.[Date] = s.[Invoice Date Key]
WHERE [Fiscal Year] IN (2015,2016)
GROUP BY
  d.[Fiscal Year],
  d.[Fiscal Month Number],
  d.[Fiscal Month Label]
ORDER BY
  d.[Fiscal Year], [Fiscal Month Number]