-- Question 3
SELECT MAX([Fiscal Year])
FROM dimDate

-- Question 4
SELECT d.[Fiscal Year]
, SUM([Total Excluding Tax]) AS SalesTotal
FROM dimDate AS d
LEFT JOIN factSale AS s ON s.[Invoice Date Key] = d.[Date]
GROUP BY d.[Fiscal Year]
ORDER BY d.[Fiscal Year]