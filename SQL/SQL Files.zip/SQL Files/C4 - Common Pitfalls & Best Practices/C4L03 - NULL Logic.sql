SELECT
  TOP (25) ProductKey,
  EnglishProductName,
  Weight,
  ListPrice,
  ListPrice / Weight AS PricePerWeight
FROM
  DimProduct
WHERE
  (
    Weight IS NOT NULL
    AND ListPrice IS NULL
  )
  OR (
    Weight IS NULL
    AND ListPrice IS NOT NULL
  )
ORDER BY
  ProductKey;

SELECT
  COUNT(*) AS TotalRows,
  COUNT(MiddleName) AS NonNullMiddleNames
FROM
  DimCustomer