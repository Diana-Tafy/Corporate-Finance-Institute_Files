-- Step 1: Count rows in the fact table
SELECT
    COUNT(*) AS FactRowCount
FROM FactInternetSales

-- Step 2: Count rows after joining to the customer dimension
SELECT
    COUNT(*) AS JoinedRowCount
FROM FactInternetSales AS fis
INNER JOIN DimCustomer AS c
    ON fis.CustomerKey = c.CustomerKey

-- Step 3: Compare distinct customers in the fact table vs joined result
SELECT
    COUNT(DISTINCT CustomerKey) AS DistinctCustomersInFact
FROM FactInternetSales

SELECT
    COUNT(DISTINCT fis.CustomerKey) AS DistinctCustomersAfterJoin
FROM FactInternetSales AS fis
INNER JOIN dbo.DimCustomer AS c
    ON fis.CustomerKey = c.CustomerKey


-- Step 1: Total sales directly from the fact table
SELECT
    SUM(SalesAmount) AS TotalSales_FactOnly
FROM FactInternetSales

-- Step 2: Total sales after joining to the customer dimension
SELECT
    SUM(fis.SalesAmount) AS TotalSales_AfterJoin
FROM FactInternetSales AS fis
INNER JOIN DimCustomer AS c
    ON fis.CustomerKey = c.CustomerKey

SELECT
    SUM(fis.SalesAmount) AS TotalSales_AfterBadJoin
FROM FactInternetSales AS fis
INNER JOIN FactProductInventory AS fpi
    ON fis.ProductKey = fpi.ProductKey

SELECT
    COUNT(*) AS SalesRowCount
FROM FactInternetSales

SELECT
    COUNT(*) AS RowCount_AfterBadJoin
FROM FactInternetSales AS fis
INNER JOIN FactProductInventory AS fpi
    ON fis.ProductKey = fpi.ProductKey