SELECT
    SUM(SalesAmount) AS TotalSales_FactOnly
FROM FactInternetSales

SELECT TOP (100) *
FROM FactProductInventory

SELECT
    fis.ProductKey,
    fpi.ProductKey,
    fpi.DateKey,
    SUM(fis.SalesAmount) AS TotalSales_AfterBadJoin
FROM FactInternetSales AS fis
INNER JOIN FactProductInventory AS fpi
    ON fis.ProductKey = fpi.ProductKey
GROUP BY fis.ProductKey,
    fpi.ProductKey,
    fpi.DateKey