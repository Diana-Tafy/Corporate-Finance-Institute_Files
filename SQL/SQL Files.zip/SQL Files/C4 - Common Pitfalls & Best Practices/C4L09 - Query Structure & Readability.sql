SELECT
    d.CalendarYear,
    d.EnglishMonthName,
    c.CustomerKey,
    c.FirstName,
    c.LastName,
    SUM(fis.SalesAmount) AS TotalSales

FROM FactInternetSales AS fis
INNER JOIN DimDate AS d
    ON fis.OrderDateKey = d.DateKey
INNER JOIN DimCustomer AS c
    ON fis.CustomerKey = c.CustomerKey

WHERE d.CalendarYear = 2013

GROUP BY
    d.CalendarYear,
    d.EnglishMonthName,
    c.CustomerKey,
    c.FirstName,
    c.LastName
    
ORDER BY
    d.CalendarYear,
    d.EnglishMonthName,
    TotalSales DESC