SELECT TOP (50)
    CustomerKey,
    Gender,
    YearlyIncome,
    EnglishEducation
FROM DimCustomer
WHERE Gender = 'F'
    AND YearlyIncome > 50000
    OR EnglishEducation = 'Bachelors'

/* Interpreted as:

(Gender = 'F' AND YearlyIncome > 50000)
OR EnglishEducation = 'Bachelors'

*/

SELECT TOP (50)
    CustomerKey,
    Gender,
    YearlyIncome,
    EnglishEducation
FROM DimCustomer
WHERE Gender = 'F'
    AND (
        YearlyIncome > 50000
        OR EnglishEducation = 'Bachelors'
    )