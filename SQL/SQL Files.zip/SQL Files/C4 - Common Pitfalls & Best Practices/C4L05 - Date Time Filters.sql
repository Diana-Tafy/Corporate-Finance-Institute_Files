SELECT 
    EmployeeKey,
    SalesOrderNumber,
    OrderDate
FROM FactResellerSales
WHERE OrderDate BETWEEN '2013-01-01' AND '2013-01-31'
ORDER BY OrderDate

/* if OrderDate is datetime, 
could exclude txns on 2013-01-31 after 0000 time
*/

SELECT
    EmployeeKey,
    SalesOrderNumber,
    OrderDate
FROM FactResellerSales
WHERE OrderDate >= '2013-01-01'
  AND OrderDate <  '2013-02-01'
ORDER BY OrderDate

SELECT *
FROM
(
    VALUES
        (1, CAST('2013-01-31T00:00:00' AS datetime)),
        (2, CAST('2013-01-31T12:30:00' AS datetime)),
        (3, CAST('2013-02-01T00:00:00' AS datetime))
) AS x(OrderID, OrderDate)
WHERE OrderDate BETWEEN '2013-01-01' AND '2013-01-31'
--WHERE OrderDate >= '2013-01-01' AND OrderDate < '2013-02-01'