SELECT EnglishProductName
FROM DimProduct
WHERE EnglishProductName LIKE '%touring%'

SELECT SERVERPROPERTY('Collation') AS ServerCollation;
/*
Latin1_General refers to the language/sort rules
CI means case-insensitive / CS means case-sensitive
AI means accent-insensitive / AS means accent-sensitive
*/

SELECT
    'café' AS RegularText,
    N'café' AS UnicodeText,
    SQL_VARIANT_PROPERTY('café', 'BaseType') AS RegularTextType,
    SQL_VARIANT_PROPERTY(N'café', 'BaseType') AS UnicodeTextType

SELECT
    '안녕하세요' AS RegularText,
    N'안녕하세요' AS UnicodeText,
    SQL_VARIANT_PROPERTY('안녕하세요', 'BaseType') AS RegularTextType,
    SQL_VARIANT_PROPERTY(N'안녕하세요', 'BaseType') AS UnicodeTextType;

SELECT TOP (20)
    EnglishProductName,
    UPPER(EnglishProductName) AS ProductName_Upper,
    LTRIM(RTRIM(EnglishProductName)) AS ProductName_Trimmed
FROM DimProduct