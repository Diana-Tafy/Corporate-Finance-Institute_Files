-- Prepare source rows
WITH CTE_InternetOrders AS
(
    SELECT
        fis.CustomerKey,
        d.FullDateAlternateKey AS OrderDate

    FROM FactInternetSales fis
    INNER JOIN DimDate d
        ON d.DateKey = fis.OrderDateKey
),

-- Summarize 
CTE_LatestOrders AS
(
    SELECT
        CustomerKey,
        MAX(OrderDate) AS LatestInternetOrderDate

    FROM CTE_InternetOrders

    GROUP BY CustomerKey
),

-- Rank
CTE_RankedCustomers AS
(
    SELECT
        CustomerKey,
        LatestInternetOrderDate,
        ROW_NUMBER() OVER (
            ORDER BY LatestInternetOrderDate DESC
        ) AS OrderRank
        
    FROM CTE_LatestOrders
)

-- Final Query
SELECT
    c.CustomerKey,
    c.FirstName,
    c.LastName,
    rc.LatestInternetOrderDate,
    rc.OrderRank

FROM DimCustomer c
LEFT JOIN CTE_RankedCustomers rc
    ON c.CustomerKey = rc.CustomerKey

WHERE c.CustomerKey LIKE '1100%'

ORDER BY rc.LatestInternetOrderDate DESC;