SELECT
  CustomerKey,
  SalesOrderNumber,
  CONVERT(date, OrderDate) AS OrderDate,
  SalesAmount,
  (
    SELECT
      AVG(SalesAmount)
    FROM
      FactInternetSales
  )
FROM
  FactInternetSales
WHERE
  CustomerKey LIKE '1100%'
  AND SalesAmount > (
    SELECT
      AVG(SalesAmount)
    FROM
      FactInternetSales
  )
ORDER BY
  SalesAmount DESC