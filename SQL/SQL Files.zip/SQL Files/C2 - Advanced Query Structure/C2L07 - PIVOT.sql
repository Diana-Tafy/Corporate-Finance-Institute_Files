SELECT CustomerKey,
[2011],
[2012],
[2013],
[2014]

FROM
(
    SELECT
        fis.CustomerKey,
        d.CalendarYear,
        fis.SalesAmount

    FROM FactInternetSales fis

    INNER JOIN DimDate d
    ON fis.OrderDateKey = d.DateKey

    WHERE CustomerKey LIKE '1100%' 
) AS SourceData

PIVOT 
    (
        SUM(SalesAmount)
        FOR CalendarYear IN ([2011], [2012], [2013], [2014])
    
    ) AS p

ORDER BY CustomerKey
/*
SELECT ...
FROM
(
    -- source query
) AS SourceData
PIVOT
(
    AGGREGATE(ValueColumn)
    FOR ColumnToTurnIntoHeaders IN ([Header1], [Header2], [Header3])
) AS p
*/