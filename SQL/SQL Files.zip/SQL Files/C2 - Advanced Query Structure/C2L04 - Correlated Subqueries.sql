SELECT 
    c.CustomerKey,
    c.FirstName,
    c.LastName,
    (
        SELECT MAX(OrderDate)
        FROM FactInternetSales fis
        WHERE fis.CustomerKey = c.CustomerKey
    ) AS MaxOrderDate

FROM DimCustomer c

WHERE CustomerKey LIKE '1100%'