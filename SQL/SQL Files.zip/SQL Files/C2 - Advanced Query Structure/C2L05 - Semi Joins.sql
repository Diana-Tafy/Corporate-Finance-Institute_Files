SELECT 
    c.CustomerKey,
    c.FirstName,
    c.LastName

FROM DimCustomer c

WHERE EXISTS 
( 
    SELECT 1
    FROM FactInternetSales fis
    WHERE LEFT(OrderDateKey, 4) = 2014
    AND fis.CustomerKey = c.CustomerKey
)

ORDER BY c.CustomerKey