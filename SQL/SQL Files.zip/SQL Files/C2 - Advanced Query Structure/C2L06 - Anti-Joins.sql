SELECT COUNT(CustomerKey) AS NumCustomers
    -- c.CustomerKey,
    -- c.FirstName,
    -- c.LastName

FROM DimCustomer c

WHERE NOT EXISTS
(
    SELECT 1
    FROM FactInternetSales fis
    WHERE LEFT(OrderDateKey, 4) = 2014
    AND fis.CustomerKey = c.CustomerKey
)