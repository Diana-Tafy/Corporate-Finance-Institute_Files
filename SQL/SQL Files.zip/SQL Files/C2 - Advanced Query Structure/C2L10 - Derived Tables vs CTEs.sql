-- Derived Table
SELECT
    c.CustomerKey,
    c.FirstName,
    c.LastName,
    x.LatestInternetOrderDate
FROM DimCustomer c
LEFT JOIN
(
    SELECT
        fis.CustomerKey,
        MAX(d.FullDateAlternateKey) AS LatestInternetOrderDate
    FROM FactInternetSales fis
    INNER JOIN DimDate d
        ON d.DateKey = fis.OrderDateKey
    GROUP BY fis.CustomerKey
) x
    ON c.CustomerKey = x.CustomerKey
WHERE c.CustomerKey LIKE '1100%'
ORDER BY x.LatestInternetOrderDate DESC;

-- CTE
WITH LatestOrders AS
(
    SELECT
        fis.CustomerKey,
        MAX(d.FullDateAlternateKey) AS LatestInternetOrderDate
    FROM FactInternetSales fis
    INNER JOIN DimDate d
        ON d.DateKey = fis.OrderDateKey
    GROUP BY fis.CustomerKey
)
SELECT
    c.CustomerKey,
    c.FirstName,
    c.LastName,
    lo.LatestInternetOrderDate
FROM DimCustomer c
LEFT JOIN LatestOrders lo
    ON c.CustomerKey = lo.CustomerKey
WHERE c.CustomerKey LIKE '1100%'
ORDER BY lo.LatestInternetOrderDate DESC;