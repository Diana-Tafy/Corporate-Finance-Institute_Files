 SELECT
        CustomerKey,
        SalesOrderNumber,
        CONVERT(date, OrderDate) AS OrderDate,
        SalesAmount,
        ROW_NUMBER() OVER (
            PARTITION BY CustomerKey
            ORDER BY OrderDate DESC, SalesAmount DESC
        ) AS rn
    FROM FactInternetSales
    WHERE CustomerKey LIKE '1100%'