SELECT
  d.CalendarYear,
  pc.EnglishProductCategoryName AS ProductCategory,
  SUM(fis.SalesAmount) AS Sales
FROM
  FactInternetSales fis
  INNER JOIN DimDate d ON fis.OrderDateKey = d.DateKey
  INNER JOIN DimProduct p ON fis.ProductKey = p.ProductKey
  INNER JOIN DimProductSubcategory ps ON p.ProductSubcategoryKey = ps.ProductSubcategoryKey
  INNER JOIN DimProductCategory pc ON ps.ProductCategoryKey = pc.ProductCategoryKey
GROUP BY
  CUBE (d.CalendarYear, pc.EnglishProductCategoryName);