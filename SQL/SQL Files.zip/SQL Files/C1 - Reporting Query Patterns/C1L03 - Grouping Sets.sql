SELECT
  CalendarYear,
  pc.EnglishProductCategoryName AS ProductCategory,
  SUM(SalesAmount) AS Sales
FROM
  FactInternetSales fis
  INNER JOIN DimDate d ON fis.OrderDateKey = d.DateKey
  INNER JOIN DimProduct p ON fis.ProductKey = p.ProductKey
  INNER JOIN DimProductSubcategory ps ON p.ProductSubcategoryKey = ps.ProductSubcategoryKey
  INNER JOIN DimProductCategory pc ON ps.ProductCategoryKey = pc.ProductCategoryKey
GROUP BY
  CalendarYear,
  pc.EnglishProductCategoryName
ORDER BY 
CalendarYear, 
ProductCategory

/*
UNION ALL

SELECT
  CalendarYear,
  NULL,
  SUM(SalesAmount)
FROM
  FactInternetSales fis
  INNER JOIN DimDate d ON fis.OrderDateKey = d.DateKey
GROUP BY
  CalendarYear
ORDER BY
  CalendarYear,
  ProductCategory
*/
/*
UNION ALL

SELECT
  NULL,
  NULL,
  SUM(SalesAmount)
FROM
  FactInternetSales fis
ORDER BY
  CalendarYear,
  ProductCategory
*/

SELECT
  d.CalendarYear,
  pc.EnglishProductCategoryName AS ProductCategory,
  SUM(fis.SalesAmount) AS Sales
FROM
  FactInternetSales fis
  INNER JOIN DimDate d ON fis.OrderDateKey = d.DateKey
  INNER JOIN DimProduct p ON fis.ProductKey = p.ProductKey
  INNER JOIN DimProductSubcategory ps ON p.ProductSubcategoryKey = ps.ProductSubcategoryKey
  INNER JOIN DimProductCategory pc ON ps.ProductCategoryKey = pc.ProductCategoryKey
GROUP BY
  GROUPING SETS (
    (d.CalendarYear, pc.EnglishProductCategoryName),
    (d.CalendarYear),
    ()
  );