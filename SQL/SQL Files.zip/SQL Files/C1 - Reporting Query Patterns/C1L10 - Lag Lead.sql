SELECT
    CustomerKey,
    CONVERT(date, OrderDate) AS OrderDate,
    SUM(SalesAmount) AS DailySales,
    LEAD(SUM(SalesAmount)) OVER (
        PARTITION BY CustomerKey
        ORDER BY OrderDate
    ) AS NextDaySales

FROM FactInternetSales

WHERE CustomerKey LIKE '1100%'

GROUP BY CustomerKey, OrderDate

ORDER BY CustomerKey, OrderDate;