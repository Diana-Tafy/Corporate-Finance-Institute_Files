SELECT
    CustomerKey,
    CONVERT(date, OrderDate) AS OrderDate,
    SalesAmount AS Sales,
    
    -- Running Total
    SUM(SalesAmount) OVER (
        PARTITION BY CustomerKey
        ORDER BY OrderDate
        ROWS BETWEEN UNBOUNDED PRECEDING AND CURRENT ROW
    ) AS RunningTotalStart,
    
    -- Previous and Current Rows
    SUM(SalesAmount) OVER (
        PARTITION BY CustomerKey
        ORDER BY OrderDate
        ROWS BETWEEN 1 PRECEDING AND CURRENT ROW
    ) AS PreviousAndCurrent,

    -- Previous and Next Rows
    SUM(SalesAmount) OVER (
        PARTITION BY CustomerKey
        ORDER BY OrderDate
        ROWS BETWEEN 1 PRECEDING AND 1 FOLLOWING
    ) AS PreviousAndNext,

    -- Running Total
    SUM(SalesAmount) OVER (
        PARTITION BY CustomerKey
        ORDER BY OrderDate
        ROWS BETWEEN CURRENT ROW AND UNBOUNDED FOLLOWING
    ) AS RunningTotalEnd

FROM FactInternetSales

WHERE CustomerKey LIKE '1100%'

ORDER BY CustomerKey, OrderDate
