SELECT
    CustomerKey,
    SalesOrderNumber,
    CONVERT(date, OrderDate) AS OrderDate,
    SalesAmount AS DailySales,
    SUM(SalesAmount) OVER (
        PARTITION BY CustomerKey
        ORDER BY OrderDate
        ROWS BETWEEN UNBOUNDED PRECEDING AND CURRENT ROW
    ) AS RunningTotalSales

FROM FactInternetSales

WHERE CustomerKey LIKE '1100%'

ORDER BY CustomerKey, OrderDate