SELECT
    CustomerKey,
    SalesOrderNumber,
    SalesAmount,
    RANK() OVER (
        PARTITION BY CustomerKey
        ORDER BY SalesAmount DESC
    ) AS Rank

FROM FactInternetSales
WHERE CustomerKey LIKE '1100%'

ORDER BY SalesAmount DESC