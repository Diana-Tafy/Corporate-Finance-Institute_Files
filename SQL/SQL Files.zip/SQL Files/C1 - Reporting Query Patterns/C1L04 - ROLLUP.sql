SELECT
    d.CalendarYear,
    d.CalendarQuarter,
    d.MonthNumberOfYear,
    SUM(fis.SalesAmount) AS Sales
FROM FactInternetSales fis
INNER JOIN DimDate d ON fis.OrderDateKey = d.DateKey

GROUP BY GROUPING SETS
(
   (d.CalendarYear, d.CalendarQuarter, d.MonthNumberOfYear),
   (d.CalendarYear, d.CalendarQuarter),
   (d.CalendarYear),
   ()
)
-- GROUP BY ROLLUP
-- (
--     d.CalendarYear,
--     d.CalendarQuarter,
--     d.MonthNumberOfYear
-- )