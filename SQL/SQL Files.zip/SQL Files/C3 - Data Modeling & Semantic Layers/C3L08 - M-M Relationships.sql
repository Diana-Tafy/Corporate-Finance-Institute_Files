-- Fact Internet Sales
SELECT
  TOP (10) SalesOrderNumber,
  SalesOrderLineNumber,
  CustomerKey,
  ProductKey,
  OrderDateKey,
  SalesAmount
FROM
  FactInternetSales
ORDER BY
  SalesOrderNumber,
  SalesOrderLineNumber;

-- Fact Internet Sales Reason
SELECT
  TOP (10) SalesOrderNumber,
  SalesOrderLineNumber,
  SalesReasonKey
FROM
  FactInternetSalesReason
ORDER BY
  SalesOrderNumber,
  SalesOrderLineNumber,
  SalesReasonKey;

-- Compare the Grain of the tables
SELECT
  COUNT(*) AS TotalRows,
  COUNT(DISTINCT SalesOrderNumber) AS DistinctOrders
FROM
  FactInternetSales;

SELECT
  COUNT(*) AS TotalRows,
  COUNT(DISTINCT SalesOrderNumber) AS DistinctOrders
FROM
  FactInternetSalesReason;

-- Join the two tables M-M
SELECT
  TOP (20) fis.SalesOrderNumber,
  fis.SalesOrderLineNumber,
  fis.SalesAmount,
  fisr.SalesReasonKey
FROM
  FactInternetSales AS fis
  INNER JOIN FactInternetSalesReason AS fisr ON fis.SalesOrderNumber = fisr.SalesOrderNumber
  AND fis.SalesOrderLineNumber = fisr.SalesOrderLineNumber
ORDER BY
  fis.SalesOrderNumber,
  fis.SalesOrderLineNumber,
  fisr.SalesReasonKey;

-- One Sale, multiple reasons
SELECT
  fisr.SalesOrderNumber,
  fisr.SalesOrderLineNumber,
  COUNT(*) AS ReasonCount
FROM
  FactInternetSalesReason AS fisr
GROUP BY
  fisr.SalesOrderNumber,
  fisr.SalesOrderLineNumber
HAVING
  COUNT(*) > 1
ORDER BY
  ReasonCount DESC,
  fisr.SalesOrderNumber,
  fisr.SalesOrderLineNumber;

-- DimSalesReason
SELECT
  SalesReasonKey,
  SalesReasonName
FROM DimSalesReason

SELECT
  *
FROM FactInternetSales
WHERE SalesOrderNumber = 'SO61139'

SELECT
  fisr.*,
  sr.SalesReasonName
FROM FactInternetSalesReason fisr
LEFT JOIN DimSalesReason sr ON sr.SalesReasonKey = fisr.SalesReasonKey
WHERE SalesOrderNumber = 'SO61139'

-- Fact Internet Sales Total Sales
SELECT 
    COUNT(DISTINCT fis.SalesOrderNumber) AS OrderCount,
    SUM(fis.SalesAmount) AS SalesAmount
FROM FactInternetSales AS fis

-- Sales Reason Allocation
SELECT
  sr.SalesReasonName,
  COUNT(DISTINCT fis.SalesOrderNumber) AS AssociatedOrderCount,
  SUM(fis.SalesAmount) AS AssociatedSalesAmount
FROM
  FactInternetSales AS fis
  LEFT JOIN FactInternetSalesReason AS fisr ON fis.SalesOrderNumber = fisr.SalesOrderNumber
  LEFT JOIN DimSalesReason AS sr ON fisr.SalesReasonKey = sr.SalesReasonKey
GROUP BY
  GROUPING SETS (sr.SalesReasonName, ())
ORDER BY
  AssociatedOrderCount DESC;