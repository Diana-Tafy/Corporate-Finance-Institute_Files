-- Bronze views expose the raw source tables
CREATE VIEW bronze.InternetSales AS
SELECT *
FROM dbo.FactInternetSales;

CREATE VIEW bronze.Customer AS
SELECT *
FROM dbo.DimCustomer;

CREATE VIEW bronze.Product AS
SELECT *
FROM dbo.DimProduct;

CREATE VIEW bronze.Date AS
SELECT *
FROM dbo.DimDate;

-- Silver views clean and standardize useful fields
CREATE VIEW silver.InternetSales AS
SELECT
    SalesOrderNumber,
    SalesOrderLineNumber,
    OrderDateKey,
    CustomerKey,
    ProductKey,
    SalesAmount
FROM bronze.InternetSales;

CREATE VIEW silver.Customer AS
SELECT
    CustomerKey,
    CONCAT(LastName, ', ', FirstName) AS Customer
FROM bronze.Customer;

CREATE VIEW silver.Product AS
SELECT
    ProductKey,
    EnglishProductName AS Product
FROM bronze.Product;

CREATE VIEW silver.Date AS
SELECT
    DateKey,
    FullDateAlternateKey AS OrderDate
FROM bronze.Date;

-- Gold view publishes the business-ready analytical output
CREATE VIEW gold.InvoiceLineSales AS

SELECT
    s.SalesOrderNumber AS Invoice,
    MAX(d.OrderDate) AS OrderDate,
    MAX(c.Customer) AS Customer,
    s.SalesOrderLineNumber AS LineItem,
    p.Product,
    SUM(s.SalesAmount) AS TotalAmount
FROM silver.InternetSales AS s
JOIN silver.Date AS d
    ON s.OrderDateKey = d.DateKey
JOIN silver.Customer AS c
    ON s.CustomerKey = c.CustomerKey
JOIN silver.Product AS p
    ON s.ProductKey = p.ProductKey
GROUP BY
    s.SalesOrderNumber,
    s.SalesOrderLineNumber,
    p.Product;