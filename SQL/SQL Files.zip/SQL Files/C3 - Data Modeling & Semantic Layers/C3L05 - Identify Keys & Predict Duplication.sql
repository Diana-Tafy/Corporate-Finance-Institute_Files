-- DimCustomer
SELECT
    COUNT(*) AS TotalRows,
    COUNT(CustomerKey) AS NonNullCustomers,
    COUNT(DISTINCT CustomerKey) AS DistinctCustomerKeys
FROM DimCustomer;

SELECT
    CustomerKey,
    COUNT(*) AS DuplicateCustomers
FROM DimCustomer
GROUP BY CustomerKey
HAVING COUNT(*) > 1;

-- FactInternetSales
SELECT
    COUNT(*) AS TotalRows,
    COUNT(CustomerKey) AS NonNullCustomers,
    COUNT(DISTINCT CustomerKey) AS DistinctCustomerKeys
FROM FactInternetSales;

SELECT
    CustomerKey,
    COUNT(*) AS DuplicateCustomers
FROM FactInternetSales
GROUP BY CustomerKey
HAVING COUNT(*) > 1;

-- Join Tables
SELECT
    COUNT(*) AS SalesRows
FROM dbo.FactInternetSales AS fis
LEFT JOIN dbo.DimCustomer AS c
    ON fis.CustomerKey = c.CustomerKey
--WHERE c.CustomerKey IS NULL;