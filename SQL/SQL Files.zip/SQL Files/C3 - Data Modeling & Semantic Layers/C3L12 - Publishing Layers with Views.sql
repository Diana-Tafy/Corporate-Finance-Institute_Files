--CREATE OR ALTER VIEW dbo.vw_InternetSalesOrderSummary AS   
    
    SELECT
    fis.SalesOrderNumber AS Invoice,
    MAX(d.FullDateAlternateKey) AS OrderDate,
    MAX(CONCAT(c.LastName, ', ', c.FirstName)) AS Customer,
    fis.SalesOrderLineNumber AS LineItem,
    p.EnglishProductName AS Product,
    SUM(fis.SalesAmount) AS TotalAmount

    FROM
    FactInternetSales AS fis
    JOIN DimDate AS d ON fis.OrderDateKey = d.DateKey
    JOIN DimCustomer AS c ON fis.CustomerKey = c.CustomerKey
    JOIN DimProduct AS p ON fis.ProductKey = p.ProductKey

    GROUP BY
    fis.SalesOrderNumber, 
    fis.SalesOrderLineNumber,
    p.EnglishProductName


    SELECT *
    FROM vwOrdersALL
    WHERE InvoiceNumber LIKE 'SO511%'