SELECT
    c.FirstName,
    c.LastName,
    fis.SalesOrderNumber,
    fis.OrderDateKey,
    fis.CustomerKey
    
FROM FactInternetSales AS fis
LEFT JOIN DimCustomer AS c
    ON fis.CustomerKey = c.CustomerKey

WHERE c.CustomerKey LIKE '1100%'

ORDER BY fis.CustomerKey;